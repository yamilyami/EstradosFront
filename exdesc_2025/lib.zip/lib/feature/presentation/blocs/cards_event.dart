abstract class CardsEvent {}

class LoadCardsEvent extends CardsEvent {}
