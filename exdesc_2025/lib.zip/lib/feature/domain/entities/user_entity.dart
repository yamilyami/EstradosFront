class UserEntity {
  final String id;
  final String email;
  // Agregar más campos
  UserEntity({required this.id, required this.email});
}
