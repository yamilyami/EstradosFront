class UsuariosScreen {
  final String nombre;
  final String Apellido;
  final int id;

  UsuariosScreen({
    required this.nombre,
    required this.Apellido,
    required this.id,
  });
}
