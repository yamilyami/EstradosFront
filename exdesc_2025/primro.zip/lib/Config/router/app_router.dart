//mport 'package:go_router/go_router.dart';
//import 'package:exdesc_2025/pages/home_pages.dart';
//import 'package:exdesc_2025/auth/login_screen.dart';
//import 'package:exdesc_2025/auth/register_screen.dart';

//final appRouter = GoRouter(
 // routes: [
    //GoRoute(path: '/', builder: (context, state) => const Home()),
    // GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
    // GoRoute(path: '/register', builder: (context, state) => RegisterScreen()),
    // Puedes seguir agregando otras pantallas con Bloc aquí
 // ],
//);
